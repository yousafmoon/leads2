import { Component, OnInit } from "@angular/core";
import { NgbTooltipConfig } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
  providers: [NgbTooltipConfig],
})
export class DashboardComponent implements OnInit {
  showEmailSearch: boolean = false;

  emailSearch() {
    this.showEmailSearch = !this.showEmailSearch;
  }

  keyword = "name";
  domains = [
    {
      name: "Netflix",
      domain: "www.netflix.com",
      results: "2.978 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/9/9d/Flag_of_Arkansas.svg",
    },
    {
      name: "Amazon",
      domain: "www.amazon.com",
      results: "39.14 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/0/01/Flag_of_California.svg",
    },
    {
      name: "Netflix",
      domain: "www.netflix.com",
      results: "20.27 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Florida.svg",
    },
    {
      name: "Amazon",
      domain: "www.amazon.com",
      results: "39.14 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Texas.svg",
    },

    {
      name: "Netflix",
      domain: "www.amazon.com",
      results: "39.14 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Florida.svg",
    },

    {
      name: "Amazon",
      domain: "www.amazon.com",
      results: "39.14 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Texas.svg",
    },

    {
      name: "Netflix",
      domain: "www.amazon.com",
      results: "39.14 Emails",
      logo:
        "https://upload.wikimedia.org/wikipedia/commons/f/f7/Flag_of_Florida.svg",
    },
  ];

  constructor(config: NgbTooltipConfig) {
    // customize default values of tooltips used by this component tree
    config.placement = "right";
    config.triggers = "click";
  }
  ngOnInit() {}
}
